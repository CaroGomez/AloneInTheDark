package co.udea.thedivines.serviciosalud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServiciosaludApplicationTests {

	@Test
	void contextLoads() {
	}

}
